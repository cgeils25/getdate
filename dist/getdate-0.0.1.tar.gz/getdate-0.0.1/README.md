This is a simple package which includes one function to create my preferred datee-time format for log files.

Example:

```
from getdate import getdate

print(getdate())
```

output:

```
'2025-02-26_08.34.13.636609'
```
